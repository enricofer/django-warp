from django.contrib import admin
from .models import rasterMaps, datasets



# Register your models here.

admin.site.register(rasterMaps)
admin.site.register(datasets)
